#!/usr/bin/env bash

# Wyciąganie statystyk z logu minera
MINER_LOG_BASENAME=/var/log/miner/hash256_miner/hash256_miner
STATS_FILE=/dev/shm/hash256_stats.json

LAST_PROGRESS=$(grep "PROGRESS" ${MINER_LOG_BASENAME}.log | tail -n 1)
MHS="0"
ACCEPTED="0"

if [ -n "$LAST_PROGRESS" ]; then
    # Wyciąga wartość np. "1270.00" z "PROGRESS 1270.00 MH/s"
    MHS=$(echo "$LAST_PROGRESS" | awk '{print $3}')
fi

# Przeliczenie na KH/s dla poprawnego wyświetlania w HiveOS
KHS=$(echo "$MHS * 1000" | bc -l)

# Liczba znalezionych bloków / urobku
ACCEPTED=$(grep -c "FOUND" ${MINER_LOG_BASENAME}.log)

# Format JSON dla HiveOS
jq -n \
  --arg khs "$KHS" \
  --arg ac "$ACCEPTED" \
  '{hs: [$khs | tonumber], hs_units: "khs", ar: [$ac | tonumber, 0]}' > $STATS_FILE

cat $STATS_FILE
