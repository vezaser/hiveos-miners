#!/usr/bin/env bash

# Przejście do katalogu minera
cd `dirname $0`

# Wczytanie zmiennych konfiguracyjnych HiveOS
. h-manifest.conf
. /hive/miners/custom/${CUSTOM_NAME}/h-manifest.conf

# Wczytanie parametrów wpisanych we Flight Sheet
[[ -f /hive/miners/custom/${CUSTOM_NAME}/${CUSTOM_NAME}.conf ]] && . /hive/miners/custom/${CUSTOM_NAME}/${CUSTOM_NAME}.conf

# Katalog logów
MINER_LOG_BASENAME=/var/log/miner/${CUSTOM_NAME}/${CUSTOM_NAME}
mkdir -p /var/log/miner/${CUSTOM_NAME}

# Zapewnienie środowiska Node.js v20+
if ! command -v node &> /dev/null || [ $(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1) -lt 16 ]; then
    echo "Pobieranie przenośnego Node.js v16..."
    if [ ! -d "node-v16" ]; then
        curl -fsSL https://nodejs.org/dist/v16.20.2/node-v16.20.2-linux-x64.tar.xz | tar -xJ
        mv node-v16.20.2-linux-x64 node-v16
    fi
    export PATH="$(pwd)/node-v16/bin:$PATH"
fi

# Instalacja zależności
if [ ! -d "node_modules" ]; then
    echo "Instalowanie zależności npm..."
    npm install
fi

# Automatyczna kompilacja zoptymalizowanej binarki OpenCL w locie
if [ ! -f "native/bin/hash256-opencl" ]; then
    echo "Kompilowanie natywnego minera OpenCL..."
    mkdir -p native/bin
    g++ -O3 native/hash256_opencl.cpp -o native/bin/hash256-opencl -ldl
    chmod +x native/bin/hash256-opencl
fi

# Budowanie pliku .env na podstawie "Extra config arguments" z HiveOS
echo "Generowanie pliku .env..."
rm -f .env
echo "MINER_BACKEND=opencl" > .env
if [ -n "$CUSTOM_USER_CONFIG" ]; then
    echo "$CUSTOM_USER_CONFIG" | tr ' ' '\n' | grep -E "^(PRIVATE_KEY|ETH_RPC_URL|ETH_TX_RPC_URL|CUDA_BLOCKS|CUDA_THREADS|CUDA_HASHES_PER_THREAD|BROADCAST_RPCS|TIP_GWEI|MINER_WORKERS)=" >> .env
fi

# Uruchomienie z zapisem do logów
echo "Uruchamianie $CUSTOM_NAME..."
node src/native-cli.js 2>&1 | tee ${MINER_LOG_BASENAME}.log
