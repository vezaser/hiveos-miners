#!/usr/bin/env bash
[ -z "$BASH_VERSION" ] && exec /bin/bash "$0" "$@"

MINER_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$MINER_DIR" || exit 1

MINER_LOG_BASENAME=${MINER_LOG_BASENAME:-"/var/log/miner/hash256_miner/hash256_miner"}
mkdir -p "$(dirname "$MINER_LOG_BASENAME")"

# Wczytywanie konfiguracji (np. adres poola lub zmienne z HiveOS)
if [ -f ".env.local" ]; then
    set -a; source ".env.local"; set +a
fi
if [ -f "/hive-config/wallet.conf" ]; then
    source "/hive-config/wallet.conf"
    if [ -n "$CUSTOM_USER_CONFIG" ]; then
        set -a; eval "$CUSTOM_USER_CONFIG"; set +a
    fi
fi

# Wymuszenie stabilnego Node.js v16 (zapewnia zgodnosc z Bionic GLIBC 2.27 oraz Jammy)
NODE_DIR="$MINER_DIR/node-v16.14.0-linux-x64"
NODE_BIN="$NODE_DIR/bin/node"
NPM_BIN="$NODE_DIR/bin/npm"

if [ ! -f "$NODE_BIN" ]; then
    echo "Pobieranie wlasnego, stabilnego srodowiska Node.js..."
    curl -fsSL https://nodejs.org/dist/v16.14.0/node-v16.14.0-linux-x64.tar.xz | tar -xJ
fi

export PATH="$NODE_DIR/bin:$PATH"

if [ ! -d "$MINER_DIR/node_modules" ]; then
    "$NPM_BIN" install --production
fi


# Trik dla HiveOS - musi "widziec" nazwe procesu zdefiniowana w h-manifest.conf
CUSTOM_BIN="$NODE_DIR/bin/hash256_miner"
if [ ! -f "$CUSTOM_BIN" ]; then
    cp "$NODE_BIN" "$CUSTOM_BIN"
fi

# Rejestracja PID minera (potrzebne, aby statystyki w ogole ozyly)
echo $$ > /run/hive/miner.pid

# Uruchomienie koparki
exec "$CUSTOM_BIN" src/native-cli.js 2>&1 | tee "${MINER_LOG_BASENAME}.log"
