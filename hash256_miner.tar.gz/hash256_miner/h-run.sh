#!/usr/bin/env bash
[ -z "$BASH_VERSION" ] && exec /bin/bash "$0" "$@"

MINER_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
cd "$MINER_DIR" || exit 1

# Export CUSTOM_LOG_BASENAME — required by HiveOS miner-run for log rotation
export CUSTOM_LOG_BASENAME="/var/log/miner/hash256_miner/hash256_miner"
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"

# --- Environment variables ---
[[ -f "$MINER_DIR/.env.local" ]] && { set -a; source "$MINER_DIR/.env.local"; set +a; }

if [[ -f "/hive-config/wallet.conf" ]]; then
    source "/hive-config/wallet.conf"
    [[ -n "$CUSTOM_USER_CONFIG" ]] && { set -a; eval "$CUSTOM_USER_CONFIG"; set +a; }
fi

# --- Node.js runtime ---
# Use system Node if >= v16, otherwise download a local copy.
NEED_LOCAL_NODE=0
if command -v node &>/dev/null; then
    SYS_NODE_VER=$(node -e "process.stdout.write(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
    [[ "$SYS_NODE_VER" -lt 16 ]] && NEED_LOCAL_NODE=1
else
    NEED_LOCAL_NODE=1
fi

if [[ "$NEED_LOCAL_NODE" -eq 1 ]]; then
    NODE_DIR="$MINER_DIR/node-v16.14.0-linux-x64"
    if [[ ! -f "$NODE_DIR/bin/node" ]]; then
        echo "Downloading Node.js v16.14.0..."
        curl -fsSL https://nodejs.org/dist/v16.14.0/node-v16.14.0-linux-x64.tar.xz \
            | tar -xJ -C "$MINER_DIR"
    fi
    export PATH="$NODE_DIR/bin:$PATH"
    NODE_BIN="$NODE_DIR/bin/node"
    NPM_BIN="$NODE_DIR/bin/npm"
else
    NODE_BIN=$(command -v node)
    NPM_BIN=$(command -v npm)
fi

# --- Dependencies ---
if [[ ! -d "$MINER_DIR/node_modules" ]]; then
    echo "Installing npm dependencies..."
    "$NPM_BIN" install --production 2>&1
fi

# --- Native binaries ---
# The repo ships .exe files which are actually Linux ELF binaries.
# Node.js on Linux looks for filenames WITHOUT .exe extension.
# Create symlinks so both names resolve to the same binary.
for f in "$MINER_DIR"/native/bin/*.exe; do
    target="${f%.exe}"
    if [[ ! -e "$target" ]]; then
        ln -sf "$(basename "$f")" "$target"
        chmod +x "$f" "$target"
    fi
done

# --- Process alias for HiveOS agent ---
# HiveOS agent identifies the miner by process name matching CUSTOM_NAME.
# We copy (or link) the node binary so `pidof hash256_miner` works.
CUSTOM_BIN="$(dirname "$NODE_BIN")/hash256_miner"
if [[ ! -f "$CUSTOM_BIN" ]]; then
    cp "$NODE_BIN" "$CUSTOM_BIN"
fi

# --- Launch miner ---
# Use 'exec' to replace shell so the PID matches what HiveOS tracks.
# Redirect output to both screen (for `miner` command) and log file (for h-stats.sh).
"$CUSTOM_BIN" "$MINER_DIR/src/native-cli.js" 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log"
