#!/usr/bin/env bash
# h-stats.sh — sourced by the HiveOS agent every ~10s.
# Must set: $khs (total kH/s) and $stats (JSON string).

LOG_NAME="/var/log/miner/hash256_miner/hash256_miner.log"

khs=0
stats=""

if [[ -f "$LOG_NAME" ]]; then
    # Grab the last PROGRESS line for each of the 6 workers.
    # Each line looks like: 2026-05-13T09:18:25Z [PROGRESS] worker=1 mhs=783.37 bestMhs=833.56 ...
    mapfile -t mhs_lines < <(tail -n 200 "$LOG_NAME" | grep '\[PROGRESS\]' | tail -6)

    if [[ ${#mhs_lines[@]} -gt 0 ]]; then
        # Build the hs array and sum
        hs_json="["
        total_mhs=0
        first=1
        for line in "${mhs_lines[@]}"; do
            mhs=$(echo "$line" | grep -oP 'mhs=\K[0-9.]+')
            if [[ -n "$mhs" ]]; then
                [[ $first -eq 0 ]] && hs_json+=","
                hs_json+="$mhs"
                total_mhs=$(awk "BEGIN{printf \"%.2f\", $total_mhs + $mhs}")
                first=0
            fi
        done
        hs_json+="]"

        if [[ $(awk "BEGIN{print ($total_mhs > 0)}") -eq 1 ]]; then
            # khs = total MH/s * 1000 (HiveOS wants kH/s)
            khs=$(awk "BEGIN{printf \"%.0f\", $total_mhs * 1000}")

            # GPU temps and fans from HiveOS agent
            if [[ -n "$gpu_stats" ]]; then
                temp=$(echo "$gpu_stats" | jq -c '[.temp[]]' 2>/dev/null)
                fan=$(echo "$gpu_stats" | jq -c '[.fan[]]' 2>/dev/null)
            fi

            stats=$(cat <<EOF
{"hs":${hs_json},"hs_units":"mhs","temp":${temp:-[]},"fan":${fan:-[]},"algo":"cubehash256"}
EOF
)
        fi
    fi
fi
