#!/usr/bin/env bash

LOG_NAME=/var/log/miner/hash256_miner/hash256_miner.log

khs=0
stats=""

if [ -f "$LOG_NAME" ]; then
    # Szuka 6 ostatnich wpisow o hashracie z logow pracujacej koparki
    total_mhs=$(tail -n 100 "$LOG_NAME" | grep "\[PROGRESS\]" | tail -6 | grep -oP 'mhs=\K[0-9.]+' | awk '{s+=$1} END {printf "%.2f", s}')
    
    if [ ! -z "$total_mhs" ] && [ "$total_mhs" != "0.00" ]; then
        # Agent HiveOS wymaga raportowania w jednostkach kilohashy (kh/s)
        khs=$(echo "$total_mhs" | awk '{printf "%.0f", $1 * 1000}')
        
        # Wyciaganie osobnej mocy dla kazdej z GPU
        hs_arr=$(tail -n 100 "$LOG_NAME" | grep "\[PROGRESS\]" | tail -6 | grep -oP 'mhs=\K[0-9.]+' | jq -R -s -c 'split("\n")[:-1] | map(tonumber)')
        
        # Poberanie wskazan termicznych ze srodowiska HiveOS (podane przez zmienna globalna gpu_stats)
        temp=$(jq -c '[.temp[]]' <<< "$gpu_stats" 2>/dev/null)
        fan=$(jq -c '[.fan[]]' <<< "$gpu_stats" 2>/dev/null)
        
        # Tworzenie pliku JSON ze statystykami
        stats=$(jq -nc \
            --argjson hs "${hs_arr:-[]}" \
            --argjson temp "${temp:-[]}" \
            --argjson fan "${fan:-[]}" \
            '{hs: $hs, hs_units: "mhs", temp: $temp, fan: $fan, algo: "hash256"}')
    fi
fi
