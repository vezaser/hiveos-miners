#!/usr/bin/env bash
function miner_config_gen() {
    return 0
}
function miner_ver() {
    echo ""
}
