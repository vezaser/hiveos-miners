#!/usr/bin/env bash

# Przejście do katalogu minera
cd `dirname $0`

# Wczytanie zmiennych konfiguracyjnych HiveOS
. h-manifest.conf
. /hive/custom/${CUSTOM_NAME}/h-manifest.conf

# Katalog logów
MINER_LOG_BASENAME=/var/log/miner/${CUSTOM_NAME}/${CUSTOM_NAME}
mkdir -p /var/log/miner/${CUSTOM_NAME}

# Zapewnienie środowiska Node.js v20+
if ! command -v node &> /dev/null || [ $(node -v | cut -d 'v' -f 2 | cut -d '.' -f 1) -lt 20 ]; then
    echo "Pobieranie przenośnego Node.js v20..."
    if [ ! -d "node-v20" ]; then
        curl -fsSL https://nodejs.org/dist/v20.12.2/node-v20.12.2-linux-x64.tar.xz | tar -xJ
        mv node-v20.12.2-linux-x64 node-v20
    fi
    export PATH="$(pwd)/node-v20/bin:$PATH"
fi

# Instalacja zależności
if [ ! -d "node_modules" ]; then
    echo "Instalowanie zależności npm..."
    npm install
fi

# Automatyczna kompilacja zoptymalizowanej binarki CUDA w locie
if [ ! -f "native/bin/hash256-cuda" ]; then
    echo "Kompilowanie natywnego minera CUDA..."
    mkdir -p native/bin
    # -arch=native lub uniwersalne targety
    nvcc -O3 -arch=sm_80 native/hash256_cuda_driver.cpp native/hash256_cuda.cu -o native/bin/hash256-cuda
    chmod +x native/bin/hash256-cuda
fi

# Budowanie pliku .env na podstawie "Extra config arguments" z HiveOS
echo "Generowanie pliku .env..."
rm -f .env
echo "MINER_BACKEND=cuda" > .env
if [ -n "$CUSTOM_USER_CONFIG" ]; then
    echo "$CUSTOM_USER_CONFIG" | tr ' ' '\n' | grep -E "^(PRIVATE_KEY|ETH_RPC_URL|ETH_TX_RPC_URL|CUDA_BLOCKS|CUDA_THREADS|CUDA_HASHES_PER_THREAD|BROADCAST_RPCS|TIP_GWEI|MINER_WORKERS)=" >> .env
fi

# Uruchomienie z zapisem do logów
echo "Uruchamianie $CUSTOM_NAME..."
node src/native-cli.js 2>&1 | tee ${MINER_LOG_BASENAME}.log
